﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task5
{
    internal class Question6
    {
        static void Main(string[] args)
        {
         
        }
        class Player
        {
            public string Name;
            public int Score;



        }
        class Team
        {
            public int[] PlayerNme=new int[5];

        }
    }
}
